from fastapi import FastAPI
from app.scraper import scrape_site
from app.scoring import score_lead
from app.notify import notify_telegram
from app.models import Lead
from app.config import settings

app = FastAPI()

@app.get("/")
def read_root():
    return {"message": "LeadScraper API is running"}

@app.post("/scrape")
async def run_scraper():
    leads = await scrape_site()
    for lead in leads:
        lead.score = score_lead(lead)
        await notify_telegram(lead)
    return {"status": "done", "leads": [lead.dict() for lead in leads]}
