from app.models import Lead

def score_lead(lead: Lead) -> float:
    # Placeholder: Replace with real OpenAI scoring
    return 0.85
