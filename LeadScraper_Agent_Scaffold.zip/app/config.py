from dotenv import load_dotenv
import os

load_dotenv()

class Settings:
    openai_api_key: str = os.getenv("OPENAI_API_KEY")
    telegram_token: str = os.getenv("TELEGRAM_BOT_TOKEN")
    telegram_chat_id: str = os.getenv("TELEGRAM_CHAT_ID")

settings = Settings()
