from app.models import Lead
import telegram

async def notify_telegram(lead: Lead):
    # Replace with your real bot token and chat ID
    BOT_TOKEN = "your-telegram-token"
    CHAT_ID = "your-chat-id"
    bot = telegram.Bot(token=BOT_TOKEN)
    await bot.send_message(chat_id=CHAT_ID, text=f"New Lead: {lead.name} ({lead.url}) — Score: {lead.score}")
