# LeadScraper Agent

This is a modular, AI-powered lead generation bot for scraping builder job posts and auto-notifying high-value opportunities.